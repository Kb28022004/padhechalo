import React, { useEffect } from "react";
import MetaData from "../../utils/MetaData";
import { Link } from "react-router-dom";
import { Button } from "@mui/material";
import MouseIcon from "@mui/icons-material/Mouse";
import "./Home.css";
import { useCourseContext } from "../../context/courseContext";
import TrendingProducts from "../../components/trendingProducts/TrendingProducts";
import Loader from '../../components/helper/loader/Loader'


const Home = () => {
  const { loading, trendingCourses, getTrendingCourses } = useCourseContext();

  useEffect(() => {
    getTrendingCourses();
  }, []);
  return (
    <>
      <MetaData title="Padhe Chalo- Home " />
      <div className="banner">
        <p>Welcome to PadhneChalo Family </p>
        <h1>FIND AMAZING COURSES TO GROW UP BELOW</h1>
        <Link to="#container">
          <Button variant="text">
            Scroll <MouseIcon />
          </Button>
        </Link>
      </div>
      <h2 className="homeHeading">Trending Courses</h2>
      {loading ? (
        <Loader />
      ) : (
        <div className="container" id="container">
          {trendingCourses
            ? trendingCourses.map((course) => (
                <TrendingProducts course={course} />
              ))
            : "There is no any course"}
        </div>
      )}
    </>
  );
};

export default Home;
